import ic_camera from './camera.png';
import ic_cimb144 from './cimb144.png';
import ic_clear from './clear.png';
import ic_ecentrix from './ecentrix.jpeg';
import ic_failed_sent from './failed_sent.png';
import ic_ic_apps_android from './ic_apps_android.png';
import ic_ic_apps_ios from './ic_apps_ios.png';
import ic_icon_photo02 from './icon-photo02.png';
import ic_information from './Information.png';
import ic_list_debitur from './list_debitur.png';
import ic_list_kunjungan from './list_kunjungan.png';
import ic_logo from './logo.png';
import ic_main_coll from './main_coll.png';
import ic_no_picture from './nopicture.png';
import ic_person_at_home from './person-at-home.png';
import ic_rekap_terkirim from './rekap_terkirim.png';
import ic_rekap_tertunda from './rekap_tertunda.png';
import ic_rencana_kunjungan from './rencana_kunjungan.png';
import ic_send_button from './send-button.svg';
import ic_splash_screen from './splash_screen.png';
import ic_success_sent from './success_sent.png';


export {
    ic_camera,
    ic_cimb144,
    ic_clear,
    ic_ecentrix,
    ic_failed_sent,
    ic_ic_apps_android,
    ic_ic_apps_ios,
    ic_icon_photo02,
    ic_information,
    ic_list_debitur,
    ic_list_kunjungan,
    ic_logo,
    ic_main_coll,
    ic_no_picture,
    ic_person_at_home,
    ic_rekap_terkirim,
    ic_rekap_tertunda,
    ic_rencana_kunjungan,
    ic_send_button,
    ic_splash_screen,
    ic_success_sent,
}