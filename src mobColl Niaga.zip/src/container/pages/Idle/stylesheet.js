const
stylesheet = { 
    List:{
        width:10,
    },
    LoginScreenTitle:{
        color:'red',
    }
}

export default stylesheet;