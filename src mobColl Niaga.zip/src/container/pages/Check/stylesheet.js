const
stylesheet = { 
    ListItem:{
        color:'red',
    }
}

export default stylesheet;