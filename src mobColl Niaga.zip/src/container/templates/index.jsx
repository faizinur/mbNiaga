import HomeTemplates from './HomeTemplates';

export {
    HomeTemplates,
}
