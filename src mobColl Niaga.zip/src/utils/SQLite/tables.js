let DB_NAME = 'MobileCollection';
let TABLES = {
    dcoll_user: {
        column: ['key', 'value'],
        name: 'collection',
    }
}

export {
    DB_NAME,
    TABLES,
}