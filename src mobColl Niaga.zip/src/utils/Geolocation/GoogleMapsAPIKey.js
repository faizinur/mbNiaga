const APIKEY = "AIzaSyB9IULYEh32nNIA-WQtYN_QHEijJLuCe6c";
export default APIKEY;