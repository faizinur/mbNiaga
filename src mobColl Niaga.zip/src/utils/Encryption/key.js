const KEY = 'idonotknowit';

export default KEY;